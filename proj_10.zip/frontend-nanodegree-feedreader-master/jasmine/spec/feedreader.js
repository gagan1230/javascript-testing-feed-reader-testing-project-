$(function () {
    /* This is our first test suite - a test suite just contains
     * a related set of tests. This suite is all about the RSS
     * feeds definitions, the allFeeds variable in our application.
     */
    describe('RSS Feeds', function () {
        /* This is our first test - it tests to make sure that the
         * allFeeds variable has been defined and that it is not
         * empty. Experiment with this before you get started on
         * the rest of this project. What happens when you change
         * allFeeds in app.js to be an empty array and refresh the
         * page?
         */
        it('are defined', function () {
            expect(allFeeds)
                .toBeDefined();
            expect(allFeeds.length)
                .not.toBe(0);
        });


        /* Done: Write a test that loops through each feed
         * in the allFeeds object and ensures it has a URL defined
         * and that the URL is not empty.
         */

        function checkURL(i) {
            it('have non-empty URL and defined URL ', function () {
                expect(allFeeds[i].url)
                    .toBeDefined();
                expect(allFeeds[i].url)
                    .not.toEqual(''); // Check non-empty URL


            });
        }
        for (var i = 0, len = allFeeds.length; i < len; i++) {
            checkURL(i);
        }
        /* TODO: Write a test that loops through each feed
         * in the allFeeds object and ensures it has a name defined
         * and that the name is not empty.
         */

        function checkName(i) {
            it("Name is defined and not empty", function () {
                expect(allFeeds[i].name)
                    .toBeDefined();
                expect(allFeeds[i].name)
                    .not.toEqual('');
            });
        }
        for (i = 0; i < len; i++) {
            checkName(i);
        }
    });




    /* TODO: Write a new test suite named "The menu" */

    /* TODO: Write a test that ensures the menu element is
     * hidden by default. You'll have to analyze the HTML and
     * the CSS to determine how we're performing the
     * hiding/showing of the menu element.
     */
    describe("The menu", function () {
        it("hidden", function () {
            expect($('.slide-menu')
                    .css('transform'))
                .toBe("matrix(1, 0, 0, 1, -192, 0)");
            expect(document.body.classList)
                .toContain("menu-hidden");
        });
        /* TODO: Write a test that ensures the menu changes
         * visibility when the menu icon is clicked. This test
         * should have two expectations: does the menu display when
         * clicked and does it hide when clicked again.
         */
        describe("menufunction", function () {
            beforeEach(function (done) {
                $('.icon-list')
                    .click();
                setTimeout(done, 300);
            });
            it(" menu appear when it is clicked", function (done) {

                expect($('.slide-menu')
                        .css('transform'))
                    .toBe("matrix(1, 0, 0, 1, 0, 0)");
                expect(document.body.classList)
                    .not.toContain("menu-hidden");
                done(); //done function used
            });

            it("when clicked agian on menu,menu hides", function (done) {
                
                    //transform function so that menu shrinks to little space now
                    expect($('.slide-menu')
                            .css('transform'))
                        .toBe("matrix(1, 0, 0, 1, -192, 0)");
                    expect(document.body.classList)
                        .toContain("menu-hidden");
                    done();
                });
        });

    });

    /* TODO: Write a new test suite named "Initial Entries" */
    describe("Initial Entries", function () {

        // Allows testing of async functions
        beforeEach(function (done) {
            loadFeed(1, done);
        });
        it("should load at least a single entry element", function () {
            
                expect($('.feed .entry')
                        .length)
                    .toBeGreaterThan(0);
            });
    });
    /* TODO: Write a test that ensures when the loadFeed
     * function is called and completes its work, there is at least
     * a single .entry element within the .feed container.
     * Remember, loadFeed() is asynchronous so this test will require
     * the use of Jasmine's beforeEach and asynchronous done() function.
     */

    /* TODO: Write a new test suite named "New Feed Selection" */
    describe("New Feed Selection", function () {

        var oldFirstEntryHeading;
        beforeAll(function (done) {
            loadFeed(0, function () {
                oldFirstEntryHeading = $('.feed .entry > h2')
                    .first()
                    .text();
                done();
            });
        });
        beforeEach(function (done) {
            loadFeed(2, done);
        });
        /* TODO: Write a test that ensures when a new feed is loaded
         * by the loadFeed function that the content actually changes.
         * Remember, loadFeed() is asynchronous.
         */
        it("when new feed  loads,content changes", function () {
            var newFirstEntry = $('.feed .entry > h2')
                .first()
                .text();

            // Test that spec is working correctly
            console.log('T spec works correctly:');
            console.log("Old feed first heading:", oldFirstEntryHeading);
            console.log("New feed first heading:", newFirstEntry);

            expect(newFirstEntry)
                .not.toBe(oldFirstEntryHeading);
        });
    });

}());
